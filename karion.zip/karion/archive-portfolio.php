<?php
/**
 * The template for displaying Archive Portfolio - Postype UI
 *
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 * @since 1.0.0
 */
exit();
get_header(); 
?>
<div id="page-portfolio-archive">
    <div class="container">
        <div class="row">
        </div>
    </div>
</div>

<?php get_footer(); ?>
