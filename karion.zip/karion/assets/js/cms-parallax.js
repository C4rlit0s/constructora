(function ($) {
    "use strict";
    $.Scrollax();
})(jQuery);